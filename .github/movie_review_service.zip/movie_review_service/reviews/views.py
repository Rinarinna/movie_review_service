from django.shortcuts import render
from django.http import JsonResponse
import pickle
import os

# Загрузка обученной модели
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'sentiment_model.pkl')
with open(MODEL_PATH, 'rb') as f:
    model = pickle.load(f)

def classify_review(request):
    if request.method == 'POST':
        review = request.POST.get('review')
        if not review:
            return JsonResponse({'error': 'No review provided'}, status=400)
        
        # Прогнозирование
        sentiment = model.predict([review])[0]
        rating = 10 if sentiment == 1 else 1  # Присваиваем рейтинг
        status = 'Positive' if sentiment == 1 else 'Negative'
        
        return JsonResponse({'review': review, 'rating': rating, 'status': status})

    return render(request, 'review_form.html')

